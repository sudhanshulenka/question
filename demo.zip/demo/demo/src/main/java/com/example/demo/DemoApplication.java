package com.example.demo;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.simp.SimpMessagingTemplate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootApplication
public class DemoApplication {

	private Map<String, Long> hitCount = new HashMap<>();
	private Map<String, Long> cityWiseCount = new HashMap<>();
	private Map<String, Long> moduleWiseCount = new HashMap<>();

	public static void main(String[] args) throws Exception {
		ConfigurableApplicationContext context = SpringApplication.run(DemoApplication.class, args);
		MessageListener listener = context.getBean(MessageListener.class);
		listener.kafkaListener.await(10, TimeUnit.SECONDS);

	}

	@Bean
	public MessageListener messageListener() {
		return new MessageListener();
	}

	@Autowired
	private SimpMessagingTemplate brokerMessagingTemplate;

	public class MessageListener {
		private CountDownLatch kafkaListener = new CountDownLatch(1);
		ObjectMapper objectMapper = new ObjectMapper();

		@KafkaListener(topics = "${topic.name}", containerFactory = "kafkaListenerContainerFactory")
		public void kafkaListener(String msg) throws Exception {

			if (null != msg) {
				Long hitRecord = hitCount.get("HitCount");
				if (null != hitRecord) {
					hitRecord = hitRecord + 1l;
				} else {
					hitRecord = 1l;
				}
				
				hitCount.put("HitCount", hitRecord);
			
				Map<String, Object> data = objectMapper.readValue(msg, new TypeReference<Map<String, Object>>() {
				});

				String moduleName = (String) data.get("module_id_str");
				if (null != moduleName) {
					Long count = moduleWiseCount.get(moduleName);
					if (null != count) {
						count = count + 1l;
					} else {
						count = 1l;
					}
					moduleWiseCount.put(moduleName, count);
				}

				String cityName = (String) data.get("xs_city_name");
				if (null != cityName) {
					Long count = cityWiseCount.get(cityName);
					if (null != count) {
						count = count + 1l;
					} else {
						count = 1l;
					}
					cityWiseCount.put(cityName, count);
				}

				String hitCountResult = objectMapper.writeValueAsString(hitCount);
				String cityWiseResult = objectMapper.writeValueAsString(cityWiseCount);
				String moduleWiseResult = objectMapper.writeValueAsString(moduleWiseCount);

				brokerMessagingTemplate.convertAndSend("/topics/event",
						hitCountResult + "\n" + cityWiseResult + "\n" + moduleWiseResult);
				this.kafkaListener.countDown();
			}
		}
	}
}
