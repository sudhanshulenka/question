package com.example.demo;

import java.util.Map;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CheckObjectConversion {

	public static void main(String[] args) {
		ObjectMapper objectMapper = new ObjectMapper();
		/*Map<String, Object> data = objectMapper.readValue(null, new TypeReference<Map<String, Object>>() {
		});*/
	}

}
