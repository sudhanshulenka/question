package com.interview.sudhanshu.interview.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.interview.sudhanshu.interview.model.Employee;

@Repository
public interface EmployeeRepo extends JpaRepository<Employee, Long> {

	@Query(value = "SELECT emp FROM Employee emp WHERE ((emp.userDetails.firstName LIKE '%:empName%') OR (emp.userDetails.lastName LIKE '%:empName%'))")
	List<Employee> findNameContaining(String empName);

	Employee findByEmpCode(String empCode);

}
