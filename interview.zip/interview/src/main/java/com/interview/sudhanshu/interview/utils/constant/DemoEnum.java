package com.interview.sudhanshu.interview.utils.constant;

public enum DemoEnum {
	DEMO1
}
