package com.interview.sudhanshu.interview.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class InterviewExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(Exception.class)
	public final ResponseEntity<Map<String, String>> handleAllExceptions(Exception ex, WebRequest request) {

		return new ResponseEntity<>(new HashMap<String, String>(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
