package com.interview.sudhanshu.interview.controller;

import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.interview.sudhanshu.interview.model.Employee;
import com.interview.sudhanshu.interview.repo.EmployeeRepo;

@RestController
@EnableAutoConfiguration
@RequestMapping("/api")
//@Api(value = "Employee Management", description = "All operations related to Employee")
public class EmployeeController {

	@Autowired
	EmployeeRepo employeeRepo;

	@RequestMapping(value = "/employee", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> addEmployee(@RequestBody Employee empl) throws Exception {

		return ResponseEntity.ok(empl);
	}

	@RequestMapping(value = "/employee/{empCode}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> getEmployee(@NotNull @PathVariable String empCode) throws Exception {
		Employee employee = employeeRepo.findByEmpCode(empCode);
		if (employee != null) {

			return ResponseEntity.ok(employee);
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	@RequestMapping(value = "/employee", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> updateEmployee(@RequestBody Employee employee) throws Exception {

		return ResponseEntity.ok(employee);
	}

	@RequestMapping(value = "/employee/{empCode}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Employee> deleteEmployee(@NotNull @PathVariable String empCode) throws Exception {
		Employee employee = employeeRepo.findByEmpCode(empCode);
		if (employee != null) {
			employeeRepo.delete(employee);
			return ResponseEntity.noContent().build();
		} else {
			return ResponseEntity.notFound().build();
		}
	}

}
