package com.interview.sudhanshu.interview.service;

public interface EmployeeService {

}
